# menetrend
Kecskemét menetrend
